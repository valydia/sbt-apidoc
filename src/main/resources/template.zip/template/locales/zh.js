define({
    zh: {
        'Allowed values:'             : '允許值:',
        'Compare all with predecessor': '预先比较所有',
        'compare changes to:'         : '比较变更:',
        'compared to'                 : '对比',
        'Default value:'              : '默认值:',
        'Description'                 : '描述',
        'Field'                       : '字段',
        'General'                     : '概括',
        'Generated with'              : '生成工具',
        'Name'                        : '名称',
        'No response values.'         : '无响应值.',
        'optional'                    : '选项',
        'Parameter'                   : '参数',
        'Permission:'                 : '允许:',
        'Response'                    : '響應',
        'Send'                        : '發送',
        'Send a Sample Request'       : '發送樣品申請',
        'show up to version:'         : '显示到版本:',
        'Size range:'                 : '尺寸範圍:',
        'Type'                        : '类型',
        'url'                         : '網址'
    }
});
